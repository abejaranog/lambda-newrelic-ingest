def main(event, context):
    print("Hello from terragrunt Lambda!!")


## Execution as main 

if __name__ == "__main__":
    main(event, context)